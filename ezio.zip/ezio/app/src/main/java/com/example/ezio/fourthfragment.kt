package com.example.ezio

import androidx.fragment.app.Fragment

class fourthfragment:Fragment(R.layout.fragment_fourth) {
}