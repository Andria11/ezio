package com.example.ezio

import androidx.fragment.app.Fragment

class thirdfragment : Fragment (R.layout.fragment_third) {
}